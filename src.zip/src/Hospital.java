
public class Hospital {
     private String name;
     private double address;
     private int phoneNumber;
}
